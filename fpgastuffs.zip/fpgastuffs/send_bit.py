import serial
import time

ser = serial.Serial("COM7", 115200)

time.sleep(1)

ser.write(b"0")

ser.close()

print("Sent one extra 0 bit")