import re
import urllib.request
from pathlib import Path

# ------------------------------------------------------------
# Cell types recovered from the Jane Street ASIC netlist
# ------------------------------------------------------------

CELL_TYPES = [
    "a2111oi_2",
    "a211o_2",
    "a211oi_2",
    "a21bo_2",
    "a21boi_2",
    "a21o_2",
    "a21oi_2",
    "a221o_2",
    "a221oi_2",
    "a22o_2",
    "a22oi_2",
    "a311o_2",
    "a31o_2",
    "a31oi_2",
    "a32o_2",
    "a41oi_2",
    "and2_2",
    "and2b_2",
    "and3_2",
    "and3b_2",
    "and4_2",
    "and4b_2",
    "and4bb_2",
    "buf_2",
    "clkbuf_16",
    "clkbuf_4",
    "clkbuf_8",
    "conb_1",
    "dfrtp_2",
    "dfstp_2",
    "dfxtp_2",
    "inv_2",
    "mux2_1",
    "nand2_2",
    "nand2b_2",
    "nand3_2",
    "nand3b_2",
    "nand4_2",
    "nor2_2",
    "nor3_2",
    "nor3b_2",
    "nor4_2",
    "nor4b_2",
    "o211a_2",
    "o211ai_2",
    "o21a_2",
    "o21ai_2",
    "o21ba_2",
    "o21bai_2",
    "o221a_2",
    "o22a_2",
    "o22ai_2",
    "o2bb2a_2",
    "o311a_2",
    "o31a_2",
    "o31ai_2",
    "o32a_2",
    "o32ai_2",
    "or2_2",
    "or3_2",
    "or3b_2",
    "or4_2",
    "or4b_2",
    "or4bb_2",
    "xnor2_2",
    "xor2_2",
]

OUTPUT_FILE = Path("sky130_cells_generated.v")

GITHUB_BASE = (
    "https://raw.githubusercontent.com/"
    "google/skywater-pdk-libs-sky130_fd_sc_hd/"
    "main/cells"
)


# ------------------------------------------------------------
# Helpers
# ------------------------------------------------------------

def base_cell_name(cell_type):
    """
    Convert:
        and2_2      -> and2
        clkbuf_16   -> clkbuf
        a2111oi_2   -> a2111oi
    """
    return cell_type.rsplit("_", 1)[0]


def full_module_name(cell_type):
    return f"sky130_fd_sc_hd__{cell_type}"


def download_functional_model(base):
    """
    Download official SkyWater functional Verilog model.
    """
    url = (
        f"{GITHUB_BASE}/{base}/"
        f"sky130_fd_sc_hd__{base}.functional.v"
    )

    print(f"Downloading {base}:")
    print(f"  {url}")

    with urllib.request.urlopen(url) as response:
        return response.read().decode("utf-8")


def extract_module(source, base, cell_type):
    """
    Extract module ... endmodule from the official functional model,
    then rename it to match the exact drive-strength cell name
    recovered from the ASIC.
    """

    original_name = f"sky130_fd_sc_hd__{base}"
    new_name = full_module_name(cell_type)

    pattern = (
        rf"\bmodule\s+{re.escape(original_name)}\b"
        rf".*?\bendmodule\b"
    )

    match = re.search(pattern, source, flags=re.DOTALL)

    if not match:
        raise RuntimeError(
            f"Could not find module {original_name} "
            f"in downloaded functional model."
        )

    module_text = match.group(0)

    module_text = re.sub(
        rf"(\bmodule\s+){re.escape(original_name)}\b",
        rf"\1{new_name}",
        module_text,
        count=1,
    )

    return module_text


# ------------------------------------------------------------
# FPGA-friendly replacements
# ------------------------------------------------------------

def generate_mux2():
    return r"""
module sky130_fd_sc_hd__mux2_1 (
    output X,
    input A0,
    input A1,
    input S
);

assign X = S ? A1 : A0;

endmodule
""".strip()


def generate_dfrtp():
    return r"""
module sky130_fd_sc_hd__dfrtp_2 (
    output reg Q,
    input CLK,
    input D,
    input RESET_B
);

always @(posedge CLK or negedge RESET_B) begin
    if (!RESET_B)
        Q <= 1'b0;
    else
        Q <= D;
end

endmodule
""".strip()


def generate_dfstp():
    return r"""
module sky130_fd_sc_hd__dfstp_2 (
    output reg Q,
    input CLK,
    input D,
    input SET_B
);

always @(posedge CLK or negedge SET_B) begin
    if (!SET_B)
        Q <= 1'b1;
    else
        Q <= D;
end

endmodule
""".strip()


def generate_dfxtp():
    return r"""
module sky130_fd_sc_hd__dfxtp_2 (
    output reg Q,
    input CLK,
    input D
);

always @(posedge CLK) begin
    Q <= D;
end

endmodule
""".strip()


SPECIAL_CELLS = {
    "mux2_1": generate_mux2,
    "dfrtp_2": generate_dfrtp,
    "dfstp_2": generate_dfstp,
    "dfxtp_2": generate_dfxtp,
}


# ------------------------------------------------------------
# Generate library
# ------------------------------------------------------------

def main():

    generated_modules = []

    header = """\
`timescale 1ns / 1ps

// ============================================================
// Generated SKY130 FPGA functional library
//
// Cell list:
//     recovered from Jane Street ASIC netlist
//
// Combinational behaviour:
//     official SkyWater SKY130 functional Verilog models
//
// Special replacements:
//     FPGA-synthesizable equivalents for cells whose official
//     simulation models depend on UDPs or other simulation-only
//     constructs.
//
// This file contains logic definitions only.
// It does NOT contain the Jane Street puzzle solution.
// ============================================================

"""

    for cell_type in CELL_TYPES:

        print(f"\nProcessing {cell_type}")

        if cell_type in SPECIAL_CELLS:
            print("  Using synthesizable FPGA replacement.")
            module = SPECIAL_CELLS[cell_type]()
            generated_modules.append(module)
            continue

        base = base_cell_name(cell_type)

        source = download_functional_model(base)

        module = extract_module(
            source=source,
            base=base,
            cell_type=cell_type,
        )

        generated_modules.append(module)

    final_text = (
        header
        + "\n\n\n".join(generated_modules)
        + "\n"
    )

    OUTPUT_FILE.write_text(
        final_text,
        encoding="utf-8"
    )

    print("\n============================================================")
    print("DONE")
    print("============================================================")
    print(f"Generated: {OUTPUT_FILE.resolve()}")
    print(f"Cell modules: {len(generated_modules)}")


if __name__ == "__main__":
    main()