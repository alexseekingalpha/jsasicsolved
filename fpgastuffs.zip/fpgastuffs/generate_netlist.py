from pathlib import Path
import re

NETLIST_FILE = Path("recovered_jane_street_netlist.txt")

text = NETLIST_FILE.read_text(encoding="utf-8")

print("Loaded recovered netlist")
print(f"Characters read: {len(text)}")
instances = {}

instance_pattern = re.compile(
    r"^(U\d+)\s*=\s*([A-Za-z0-9_]+)\s*@",
    re.MULTILINE
)

for match in instance_pattern.finditer(text):
    instance_name = match.group(1)
    cell_type = match.group(2)

    instances[instance_name] = cell_type

print(f"Instances parsed: {len(instances)}")
nets = {}

current_net = None

for line in text.splitlines():
    line = line.strip()

    if re.fullmatch(r"NET_\d+", line):
        current_net = line
        nets[current_net] = []
        continue

    if current_net is not None:
        pin_match = re.match(r"(U\d+)\.([A-Za-z0-9_]+)", line)

        if pin_match:
            instance_name = pin_match.group(1)
            pin_name = pin_match.group(2)

            nets[current_net].append(
                (instance_name, pin_name)
            )

print(f"Nets parsed: {len(nets)}")
pin_to_net = {}

for net_name, pins in nets.items():
    for instance_name, pin_name in pins:
        key = (instance_name, pin_name)
        pin_to_net[key] = net_name

print(f"Pin-to-net mappings: {len(pin_to_net)}")
instance_pins = {}

for (instance_name, pin_name), net_name in pin_to_net.items():

    if instance_name not in instance_pins:
        instance_pins[instance_name] = {}

    instance_pins[instance_name][pin_name] = net_name

print(f"Instances with pin connections: {len(instance_pins)}")
OUTPUT_FILE = Path("recovered_asic.v")


# ------------------------------------------------------------
# Recovered top-level interface
# ------------------------------------------------------------

INPUT_NETS = {
    "I": "NET_15",
    "enable": "NET_395",
    "clk": "NET_272",
    "rst_n": "NET_74",
}

OUTPUT_NETS = {
    "success": "NET_78",

    "O[0]": "NET_66",
    "O[1]": "NET_158",
    "O[2]": "NET_68",
    "O[3]": "NET_114",
    "O[4]": "NET_113",
    "O[5]": "NET_83",
    "O[6]": "NET_124",
    "O[7]": "NET_81",
}


lines = []

lines.append("`timescale 1ns / 1ps")
lines.append("")
lines.append("// Reconstructed Jane Street ASIC")
lines.append("// Automatically generated from recovered GDS connectivity.")
lines.append("")
lines.append("module recovered_asic(")
lines.append("    input wire I,")
lines.append("    input wire enable,")
lines.append("    input wire clk,")
lines.append("    input wire rst_n,")
lines.append("    output wire success,")
lines.append("    output wire [7:0] O")
lines.append(");")
lines.append("")


# ------------------------------------------------------------
# Declare the recovered electrical nets
# ------------------------------------------------------------

for net_number in range(1, 740):
    lines.append(f"wire NET_{net_number};")

lines.append("")


# ------------------------------------------------------------
# Attach external ASIC inputs to their recovered nets
# ------------------------------------------------------------

for port_name, net_name in INPUT_NETS.items():
    lines.append(f"assign {net_name} = {port_name};")

lines.append("")


# ------------------------------------------------------------
# Attach recovered nets to external ASIC outputs
# ------------------------------------------------------------

lines.append("assign success = NET_78;")

for bit in range(8):
    net_name = OUTPUT_NETS[f"O[{bit}]"]
    lines.append(f"assign O[{bit}] = {net_name};")

lines.append("")


# ------------------------------------------------------------
# NET_590 uncertainty
#
# Physical extraction found loads on NET_590 but no recovered
# driver. Our successful software reconstruction used NET_590 = 0.
# Keep this assumption explicit rather than hiding it.
# ------------------------------------------------------------

lines.append("// Unresolved physical net: explicit current assumption")
lines.append("assign NET_590 = 1'b0;")
lines.append("")


# ------------------------------------------------------------
# Instantiate all 728 recovered standard cells
# ------------------------------------------------------------

def instance_number(name):
    return int(name[1:])


for instance_name in sorted(instances, key=instance_number):

    cell_type = instances[instance_name]
    module_name = f"sky130_fd_sc_hd__{cell_type}"

    pins = instance_pins[instance_name]

    lines.append(f"{module_name} {instance_name} (")

    pin_items = list(pins.items())

    for index, (pin_name, net_name) in enumerate(pin_items):

        comma = "," if index < len(pin_items) - 1 else ""

        lines.append(
            f"    .{pin_name}({net_name}){comma}"
        )

    lines.append(");")
    lines.append("")


lines.append("endmodule")
lines.append("")


OUTPUT_FILE.write_text(
    "\n".join(lines),
    encoding="utf-8"
)

print(f"Generated Verilog: {OUTPUT_FILE.resolve()}")
print(f"Instances generated: {len(instances)}")
print(f"Nets declared: {len(nets)}")